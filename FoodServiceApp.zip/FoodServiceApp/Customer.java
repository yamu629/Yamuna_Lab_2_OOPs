package FoodServiceApp;
import java.util.*;

public class Customer {
	private String Name;
	private String ContactNumber;
	private int cardNumber;
	private boolean paymentStatus=false;
	private boolean refundStatus=false;
	int Token;
	Customer(){
		System.out.print("Enter Customer Name: ");
		Scanner obj1=new Scanner(System.in);
		Name=obj1.nextLine();
		System.out.print("Enter Contact Number: ");
		obj1=new Scanner(System.in);
		String num=obj1.nextLine();
		while(isValidContactNumber(num)==false) {
			System.out.print("Invalid Contact Number. Pls enter again: ");
			obj1=new Scanner(System.in);
			num=obj1.nextLine();
		}
		
	};
	private boolean isValidContactNumber(String num) {
		// length should be 10 and all digits should be number
		if(num.length()==10) {
			try {
				double check=Double.parseDouble(num);
				ContactNumber=num;
				return true;
			}
			catch(Exception e){
				return false;
			}
		}
		return false;
	}
	public void setToken(int Token) {
		this.Token=Token;
	}
	
	//notify customer when food is ready via SMS and display token number on token display system
	public void notifyCustomer() {
		System.out.println("Order complete for token number "+Token+"\n**************");
		sendSMS(ContactNumber);
	}
	private void sendSMS(String ContactNumber) {
		//sendSMS to customer number 
	}
	protected void makePayment(int price) {
		//payment task
		System.out.println("$ "+price+" paid.");
		
		paymentStatus=true;
	}
	
	protected void refund(int price) {		
		//refund task
		System.out.println("Refunded successfully for token number "+Token+"\n***********");
		sendSMS(ContactNumber);
		paymentStatus=false;
		refundStatus=true;
	}
	protected void showDetails() {
		System.out.println(Name+", "+ContactNumber);
	}
	public boolean getPaymentStatus() {
		return paymentStatus;
	}
	public boolean getRefundStatus() {
		return refundStatus;
	}
}	
