package FoodServiceApp;
import java.util.*;

import FoodServiceApp.Pizza.toppings;
public class OrderMain {
	public static void main(String[] args) {
		showMenu();
		Scanner obj=new Scanner(System.in);
		int Option=obj.nextInt();
		if(Option>6 || Option<0) {
	    	System.out.println("Invalid Input\n**********");
	    }
		OrderSystem Order=new OrderSystem();
		int token=0;
		while(Option!=6)
		{
			switch(Option) {
				case 1:
				
					Customer c=new Customer();
					token=Order.addCustomer(c);
					c.setToken(token);
					System.out.println("Token issued: "+token);
					System.out.println("Choose from following\n1. Pizza\n2. Pasta");
					obj=new Scanner(System.in);
					int Food=obj.nextInt();
					if(Food!=1 && Food!=2) {
				    	System.out.println("Invalid Input\n**********");
				    }
					int next;
					
					while(Food==1) {
						Pizza P1=PizzaOrderMenu();
						
						System.out.println("Toppings?\n1. Yes \n2. No ");
						obj= new Scanner(System.in);
						next=obj.nextInt();
						if(next!=1 && next!=2) {
					    	System.out.println("Invalid Input\n**********");
					    }
						while (next==1){
							if(next==1) {
								int i=1;
								for(toppings P: Pizza.toppings.values()) {
									if(i<6) {
									System.out.print(i+". "+P+"\n");
									i++;
									}
								}
							}
							obj= new Scanner(System.in);
							int top=obj.nextInt();
							
							if(top>6 || top<1) {
								System.out.println("Invalid Input\n**********");
							}
							else {
								int i=1;
								for(toppings P: Pizza.toppings.values()) {
									if(top==i ){
										P1.addToppings(P);
										//P1.showDetails();
										
									}
									i++;
								}
								System.out.println("Toppings?\n1. Yes \n2. No ");
								obj= new Scanner(System.in);
								next=obj.nextInt();
								if(next!=1 && next!=2) {
							    	System.out.println("Invalid Input\n**********");
							    }
							}
						}
						
						
						Order.addOrder(P1,token);
						
						System.out.println("Another Pizza?\n1. Yes\n2. No ");
						obj=new Scanner(System.in);
						Food=obj.nextInt();
						if(Food!=1 && Food!=2) {
					    	System.out.println("Invalid Input\n**********");
					    }
						
					}
					if(Order.PizzaMap.containsKey(token)) {
						System.out.println("Choose from following\n1. Pasta\n2. None");
						obj=new Scanner(System.in);
						Food=obj.nextInt();
						if(Food!=1 && Food!=2) {
					    	System.out.println("Invalid Input\n**********");
					    }
					}
					else {
						if(Food==2) {
							Food=1;
						}
					}
					
					
					while(Food==1) {
						Pasta P2=PastaOrderMenu();
						Order.addOrder(P2,token);
						
						System.out.println("Another Pasta?\n1. Yes\n2. No: ");
						obj=new Scanner(System.in);
					    Food=obj.nextInt();	
					    if(Food!=1 && Food!=2) {
					    	System.out.println("Invalid Input\n**********");
					    }
	
					}
					Order.OrderStatus.replace(token, "Ordered");
					
					int TotalPrice=Order.showBill(token);
					if(TotalPrice==0) {
						System.out.println("Token not found\n*************");
					}
					System.out.println("Would you like to pay now?\n1. Yes 2.No");
					obj=new Scanner(System.in);
					next=obj.nextInt();
					if(next==1) {
						c.makePayment(Order.PriceMap.get(token));
						Order.CustomerMap.replace(token, c);
						Order.OrderStatus.replace(token, "Paid");
					}
					//intentionally added to delay processing by token number to allow to see order details and customer details and cancelling
					if(token>=1) {
						Order.cookInKitchen(token-1);
						Order.orderDelivery(token-1);
					}
					
					
					
					break;
				case 2:
					System.out.print("Enter token: ");
					obj=new Scanner(System.in);
					token=obj.nextInt();
					boolean status=Order.showDetails(token);
					if(status==false) {
						System.out.println("Token Error\n***********");
					}
					break;
					
				case 3:
					System.out.print("Enter token: ");
					obj=new Scanner(System.in);
					int token_inp=obj.nextInt();
					status=Order.cancelOrder(token_inp);
					if(status==false) {
						System.out.println("Order not cancelled. Try again.\n************");
					}
					else {
						System.out.println("Order cancelled.\n*********");
					}
					break;
				case 4:
					System.out.print("Enter token: ");
					obj=new Scanner(System.in);
					token_inp=obj.nextInt();
					status=Order.showCustomerDetails(token_inp);
					if(status==false) {
						System.out.println("No details found\n***********");
					}
					
				case 5:
					System.out.print("Enter token: ");
					obj=new Scanner(System.in);
					token_inp=obj.nextInt();
					Order.getorderStatus(token_inp);
					
			}
			
			showMenu();
			obj=new Scanner(System.in);
			Option=obj.nextInt();
			if(Option==6) {
				System.exit(0);
			}
				
		}
		obj.close();
		
	}
	private static void showMenu() {
		System.out.println("***********Menu**************");
		System.out.println("1. Create new order\n2. Show order details\n3. Cancel existing order\n4. Customer Details\n5. Order Status\n6. Exit ");
	}
	private static Pizza PizzaOrderMenu() {
		
			System.out.println("Choose from following type\n1. Vegetarian Small\n2. Vegan Small\n3. Nonvegetarian Small");
			System.out.println("4. Vegetarian Medium\n5. Vegan Medium\n6. Nonvegetarian Medium");
			System.out.println("7. Vegetarian Large\n8. Vegan Large\n9. Nonvegetarian Large");
			Scanner obj=new Scanner(System.in);
			int next=obj.nextInt();
			Pizza.size size;
			Pizza.flavor flavor=Pizza.flavor.VEGETARIAN;
//			Pizza.toppings toppings;
			if(next==1) {
				size=Pizza.size.SMALL;
				flavor=Pizza.flavor.VEGETARIAN;
			}
			else if(next<4) {
				size=Pizza.size.SMALL;
				if (next==2) {
					flavor=Pizza.flavor.VEGAN;
				}
				else if (next==3) {
					flavor=Pizza.flavor.NONVEGETARIAN;
				}
			}
			else if(next<7) {
				size=Pizza.size.MEDIUM;
				if(next==4) {
					flavor=Pizza.flavor.VEGETARIAN;
				}
				else if (next==5) {
					flavor=Pizza.flavor.VEGAN;
				}
				else if (next==6) {
					flavor=Pizza.flavor.NONVEGETARIAN;
				}
			}
			else {
				size=Pizza.size.LARGE;
				if(next==7) {
					flavor=Pizza.flavor.VEGETARIAN;
				}
				else if (next==8) {
					flavor=Pizza.flavor.VEGAN;
				}
				else if (next==9) {
					flavor=Pizza.flavor.NONVEGETARIAN;
				}
			}
			System.out.println("Choose from following crust\n1. Thin\n2. Thick");
			obj=new Scanner(System.in);
			next=obj.nextInt();
//			System.out.println(next);
			while (next!=1 &&next!=2){
				System.out.println("Invalid input. Enter again: ");
				obj=new Scanner(System.in);
				next=obj.nextInt();
			}
			Pizza.crust crust=Pizza.crust.THIN;
			
			if(next==2) {
				crust=Pizza.crust.THICK;
			}
			return(new Pizza(size,flavor,crust));
			
			
		
	}
	private static Pasta PastaOrderMenu() {
		
		
		System.out.println("Choose from following flavor\n1. White sauce\n2. Red Sauce");
		Scanner obj=new Scanner(System.in);
		int next=obj.nextInt();
		System.out.println(next);
		while(next!=1 && next!=2) {
			System.out.println("Invalid input\nEnter again");
			obj=new Scanner(System.in);
		}
		
		Pasta.flavor flavor=Pasta.flavor.WHITE;
		

		if(next==2) {
			 flavor=Pasta.flavor.RED;
		}
		
		System.out.println("Choose from following type\n1. Penne\n2. Ditalini\n3. Fusilli");
		obj=new Scanner(System.in);
		next=obj.nextInt();
		while(next!=1 && next!=2&&next!=3) {
			System.out.println("Invalid input\nEnter again");
			obj=new Scanner(System.in);
		}
		Pasta.type type=Pasta.type.PENNE;
		
		if(next==2) {
			type=Pasta.type.DITALINI;
		}
		else if (next==3) {
			type=Pasta.type.FUSILLI;
		}
		return(new Pasta(flavor,type));
		
		
	

	}

}
