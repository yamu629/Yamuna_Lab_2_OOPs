package FoodServiceApp;
import java.util.*;

public class OrderSystem {
	int last_token_number=0;
	public Queue<Integer> orderqueue=new LinkedList<Integer>();
	public Map<Integer,String> OrderStatus=new HashMap<Integer,String>();
	public Map<Integer,ArrayList<Pizza>> PizzaMap=new HashMap<Integer,ArrayList<Pizza>>();
	public Map<Integer,ArrayList<Pasta>> PastaMap=new HashMap<Integer,ArrayList<Pasta>>();
	public Map<Integer,Customer> CustomerMap=new HashMap<Integer,Customer>();
	public Map<Integer,Integer> PriceMap=new HashMap<Integer,Integer>();
	//add pasta for order
	public void addOrder(Pasta pasta,int token ){
		if(PastaMap.containsKey(token)) {
			int Price=PriceMap.get(token);
			ArrayList<Pasta> pastaArray=new ArrayList<Pasta>();
			ArrayList<Pasta> pastaStore=PastaMap.get(token);
			Price+=pasta.getPrice();
			for( Pasta p:pastaStore) {
				pastaArray.add(p);
			}
			pastaArray.add(pasta);
			PastaMap.put(token,  pastaArray);
			PriceMap.replace(token, Price);
		}
		else {
			ArrayList<Pasta> pastaArray=new ArrayList<Pasta>();
			pastaArray.add(pasta);
			PastaMap.put(token,  pastaArray);
			if(PriceMap.containsKey(token)) {
				int Price=PriceMap.get(token);
				Price+=pasta.getPrice();
				PriceMap.replace(token, Price);
			}
			else {
				PriceMap.put(token, pasta.getPrice());
			}
		}
	}
	//add pizza for order
	public void addOrder(Pizza pizza,int token) {
		if(PizzaMap.containsKey(token)) {
			int Price=PriceMap.get(token);
			ArrayList<Pizza> pizzaArray=new ArrayList<Pizza>();
			ArrayList<Pizza> pizzaStore=PizzaMap.get(token);
			Price+=pizza.getPrice();
			for( Pizza p:pizzaStore) {
				pizzaArray.add(p);
			}
			pizzaArray.add(pizza);
			PizzaMap.put(token,  pizzaArray);
			PriceMap.replace(token, Price);
		}
		else {
			ArrayList<Pizza> pizzaArray=new ArrayList<Pizza>();
			pizzaArray.add(pizza);
			PizzaMap.put(token,  pizzaArray);
			if(PriceMap.containsKey(token)) {
				int Price=PriceMap.get(token);
				Price+=pizza.getPrice();
				PriceMap.replace(token, Price);
			}
			else {
				PriceMap.put(token, pizza.getPrice());
			}
		}
	}
	
	//cancel order and issue refund
	public boolean cancelOrder(int token) {
		System.out.println("Sure to cancel for token "+token+" ?\n1. Yes\n2. No");
		Scanner obj=new Scanner(System.in);
		int next=obj.nextInt();
		if(next==1) {
//			System.out.println(OrderStatus.get(token));
			if(orderqueue.contains(token)&& (OrderStatus.get(token)=="Ordered"||OrderStatus.get(token)=="Paid")) {
				orderqueue.remove(token);
				if(OrderStatus.get(token)=="Ordered") {
					OrderStatus.replace(token,"Cancelled");
				}
				PizzaMap.remove(token);
				PastaMap.remove(token);
				
				if(OrderStatus.get(token)=="Paid") {
					Customer c=CustomerMap.get(token);
					c.refund(PriceMap.get(token));
					if(c.getRefundStatus()==true) {
						OrderStatus.replace(token,"Refund Issued");
					}
				}
				PriceMap.remove(token);
				CustomerMap.remove(token);
//				System.out.println(OrderStatus.get(token));
				return true;
			}
			
		}
		
	
		return false;
	}
	
	public void getorderStatus(int token) {
		if(OrderStatus.containsKey(token)) {
			System.out.println( OrderStatus.get(token));
		}
		else {
			System.out.println("Invalid Token\n*********");
		}
	}
	
	public int addCustomer(Customer c) {
		last_token_number+=1;
		orderqueue.add(last_token_number);
		OrderStatus.put(last_token_number,"Ordering");
		CustomerMap.put(last_token_number, c);
		
		return last_token_number;
	}
	//generate bill
	public int showBill(int token) {
		if(orderqueue.contains(token)) {
			ArrayList<Pizza> pizzas=new ArrayList<Pizza>();
			if(PizzaMap.containsKey(token)) {
				pizzas=PizzaMap.get(token);
				for (int i=0;i<pizzas.size();i++) {
					System.out.println("PIZZA: "+pizzas.get(i).getType());
					System.out.println("Cost: $"+pizzas.get(i).getPrice());
				}
			}
			ArrayList<Pasta> pastas=new ArrayList<Pasta>();
			if(PastaMap.containsKey(token)) {
				pastas=PastaMap.get(token);
				for (int i=0;i<pastas.size();i++) {
					System.out.println("PASTA: "+pastas.get(i).getType());
					System.out.println("Cost: $"+pastas.get(i).getPrice());
				}
			}
			
			
			System.out.println("Total Price: $"+PriceMap.get(token));
			
			return PriceMap.get(token);
		}
		return 0;
			
	}
	
	public boolean showDetails(int token) {
		if(orderqueue.contains(token)) {
			ArrayList<Pizza> pizzas=new ArrayList<Pizza>();
			if(PizzaMap.containsKey(token)) {
				pizzas=PizzaMap.get(token);
				for (int i=0;i<pizzas.size();i++) {
					pizzas.get(i).showDetails();
					
				}
			}
			ArrayList<Pasta> pastas=new ArrayList<Pasta>();
			if(PastaMap.containsKey(token)) {
				pastas=PastaMap.get(token);
				for (int i=0;i<pastas.size();i++) {
					pastas.get(i).showDetails();
				}
				
			}
			
			return true;
		}
		return false;
	}
	//notify from kitchen
	public boolean notifyfromKitchen(int token) {
		if(orderqueue.contains(token)) {
			orderqueue.remove(token);
			PizzaMap.remove(token);
			PastaMap.remove(token);
			CustomerMap.get(token).notifyCustomer();
			if(OrderStatus.get(token)=="Paid") {
				OrderStatus.replace(token, "Ready for Delivery. Paid.");
			
			}
			else {
				OrderStatus.replace(token, "Ready for Delivery. Payment pending.");	
			}
			return true;
		}
		return false;
	}
	//cook in kitchen
	public boolean cookInKitchen(int token) {
		if(orderqueue.contains(token)) {
			ArrayList<Pizza> pizzas=new ArrayList<Pizza>();
			if(PizzaMap.containsKey(token)) {
				pizzas=PizzaMap.get(token);	
				Pizza.cookInKitchen(token, pizzas);
					
				
			}
			ArrayList<Pasta> pastas=new ArrayList<Pasta>();
			if(PastaMap.containsKey(token)) {
				pastas=PastaMap.get(token);
				Pasta.cookInKitchen(token, pastas);
				
			}
			notifyfromKitchen(token);
			return true;	
		}
		return false;
	}
	
	public boolean showCustomerDetails(int token) {
		if(CustomerMap.containsKey(token)) {
			Customer c=CustomerMap.get(token);
			c.showDetails();
			return true;	
		}
		return false;
		
	}
	public boolean orderDelivery(int token) {
		if(CustomerMap.containsKey(token)) {
			if(OrderStatus.get(token)=="Ready for Delivery. Payment pending.") {
				System.out.println("Payment is pending. Kindly pay now");
				Customer c=CustomerMap.get(token);
				c.makePayment(PriceMap.get(token));
			}
			OrderStatus.replace(token, "Delivered");
			System.out.println("Delivered");
			CustomerMap.remove(token);
			PriceMap.remove(token);
			return true;
		}
		return false;
	}
	
}
