package FoodServiceApp;

import java.util.ArrayList;

public class Pasta {
	public enum flavor{
		WHITE,
		RED
	}
	public enum type{
		PENNE,
		DITALINI,
		FUSILLI
	}
	private int Price=0;
	flavor Flavor=flavor.WHITE;
	type Type=type.PENNE;
	Pasta(flavor f,type t){
		Flavor=f;
		Type=t;
		calculatePrice();
	}
	private void calculatePrice(){
		Price=10;
		
		if(Flavor.equals(flavor.RED))
		{
			Price=Price+10;
		}
	}
	
	public int getPrice() {
		return Price;
	}
	public String getType() {
		return(Flavor+", "+Type);
	}
	public void showDetails() {
		System.out.println(getType());
		System.out.println("Total Price: $"+Price);
	}
	public static boolean cookInKitchen(int token,ArrayList<Pasta> PastaList) {
		for(int i=0; i<PastaList.size();i++) {
			Pasta P=PastaList.get(i);
			for(int j=0;j<1000;j++);
			//Cook
		}
		return true;
		
	}
}
