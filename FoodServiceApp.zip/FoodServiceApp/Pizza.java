package FoodServiceApp;
import java.util.*;

public class Pizza {
	public enum size{
		LARGE,
		MEDIUM,
		SMALL
	}
	public enum crust{
		THICK,
		THIN
	}
	public enum flavor{
		VEGETARIAN,
		NONVEGETARIAN,
		VEGAN
	}
	public enum toppings{
		CHEESE,
		MUSHROOM,
		TOMATO,
		JALEPANO,
		SPINACH,
		NONE
	}

	private size Size=size.SMALL;
	private crust Crust=crust.THIN;
	private flavor Flavor=flavor.VEGETARIAN;
	private int PriceonFlavor=0;
	private int PriceonToppings=0;
	private ArrayList<toppings> Toppings=new ArrayList<toppings>();
	Pizza(){
		Toppings.add(toppings.NONE);
		calculatePrice();
	}
	
	Pizza(size S,flavor F,crust C){
		
		Size=S;
		Crust=C;
		Flavor=F;
		Toppings.add(toppings.NONE);
		calculatePrice();
	}
	//Calculate prizes on toppings and flavor
	private void calculatePrice() {
		PriceonFlavor=calculatePriceonSizeandFlavor();
		PriceonToppings=calculatePriceonToppings();
	}
	
	//Calculate price on size and flavor
	private int calculatePriceonSizeandFlavor(){
		int current_Price=0;
		//default value for vegetarian
		if(Size.equals(size.LARGE)) {
			current_Price=60;
		}
		else if(Size.equals(size.SMALL)) {
			current_Price=20;
		}
		else if(Size.equals(size.MEDIUM)) {
			current_Price=40;
		}
		//Vegan
		if(Flavor.equals(flavor.VEGAN)){
			if(Size.equals(size.LARGE)) {
				current_Price=current_Price-15;
			}
			else if(Size.equals(size.SMALL)) {
				current_Price=current_Price-5;
			}
			else if(Size.equals(size.MEDIUM)) {
				current_Price=current_Price-10;
			}	
		}
		//nonveg
		else if(Flavor.equals(flavor.NONVEGETARIAN)){
			if(Size.equals(size.LARGE)) {
				current_Price=current_Price+30;
			}
			else if(Size.equals(size.SMALL)) {
				current_Price=current_Price+10;
			}
			else if(Size.equals(size.MEDIUM)) {
				current_Price=current_Price+20;
			}
		}
	return current_Price;
	}
	
	//calculate price for toppings
	private int calculatePriceonToppings() {
		//toppings
		int current_Price=0;
		for(int i=0;i<Toppings.size();i++) {
			toppings check_top=Toppings.get(i);
			if(check_top.equals(toppings.CHEESE)) {
				current_Price=current_Price+1;
			}
			else if(check_top.equals(toppings.MUSHROOM)) {
				current_Price=current_Price+1;
			}
			else if(check_top.equals(toppings.TOMATO)) {
				current_Price=current_Price+1;
			}
			else if(check_top.equals(toppings.JALEPANO)) {
				current_Price=current_Price+1;
			}
			else if(check_top.equals(toppings.SPINACH)) {
				current_Price=current_Price+1;
			
			}
		}
		return current_Price;
		
		
	}
	//get total pizza price from outside classes
	public int getPrice() {
		return (PriceonFlavor+PriceonToppings);
	}
	
	//in case add toppings to existing pizza
	public boolean addToppings(toppings t) {
		try {
			Toppings.add(t);
		}
		catch (Exception e){
			System.out.println(e);
			return false;
		}
		PriceonToppings=calculatePriceonToppings();
		return true;
	}
	
	public String getType() {
		String output=Size+","+Flavor+","+Crust+" CRUST";
//		System.out.println(", "+Toppings.size());
		for(int i=0;i<Toppings.size();i++) {
			if(!Toppings.get(i).equals(toppings.NONE)) {
				output=output+", "+Toppings.get(i);
			}
		}
		return(output);
	}

	public void showDetails() {
		System.out.println(getType());
		System.out.println("Price on Type: $"+PriceonFlavor+"\nPrice on Toppings: "+PriceonToppings);
		int total=PriceonToppings+PriceonFlavor;
		System.out.println("Total Price: "+total);
	}
	
	public static boolean cookInKitchen(int token,ArrayList<Pizza> PizzaList) {
		for(int i=0; i<PizzaList.size();i++) {
			Pizza P=PizzaList.get(i);
			for(int j=0;j<1000;j++);
			//Cook
		}
		return true;
		
	}
	
}
